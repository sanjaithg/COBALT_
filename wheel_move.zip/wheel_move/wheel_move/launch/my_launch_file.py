import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

def generate_launch_description():
    urdf_path1 = '/home/hillman/ros2_ws/src/wheel_move/wheel_move/my_robot.urdf'
    urdf_path = '/home/hillman/ros2_ws/src/wheel_move/wheel_move/Ball.sdf'
    urdf_path2 = '/home/hillman/ros2_ws/src/wheel_move/wheel_move/World.sdf'
    # Verify the URDF and SDF files exist
    if not os.path.exists(urdf_path1):
        raise FileNotFoundError(f"URDF file not found: {urdf_path1}")
    if not os.path.exists(urdf_path):
        raise FileNotFoundError(f"SDF file not found: {urdf_path}")
    if not os.path.exists(urdf_path2):
        raise FileNotFoundError(f"URDF file not found: {urdf_path2}")

    return LaunchDescription([
        # Start Gazebo
        ExecuteProcess(
            cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_init.so', '-s', 'libgazebo_ros_factory.so'],
            output='screen'
        ),
        # Spawn my_robot
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-file', urdf_path1, '-entity', 'my_robot'],
            output='screen'
        ),
        # Spawn Ball
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-file', urdf_path, '-entity', 'Ball'],
            output='screen'
        ),
        # Spawn World
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-file', urdf_path2, '-entity', 'World'],
            output='screen'
        ),

        # Teleop for my_robot
        Node(
            package='teleop_twist_keyboard',
            executable='teleop_twist_keyboard',
            name='teleop_my_robot',
            output='screen',
            remappings=[
                ('/cmd_vel', '/my_robot/cmd_vel')
            ]
        ),
        # Teleop for Ball
        Node(
            package='teleop_twist_keyboard',
            executable='teleop_twist_keyboard',
            name='teleop_Ball',
            output='screen',
            remappings=[
                ('/cmd_vel', '/Ball/cmd_vel')
            ]
        )

    ])
