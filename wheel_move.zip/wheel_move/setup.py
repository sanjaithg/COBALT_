from setuptools import setup
from glob import glob
import os

package_name = 'wheel_move'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        (os.path.join('share', package_name), ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hillman',
    maintainer_email='hillman@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            "launch = wheel_move.launch.my_launch_file:generate_launch_description",
            "cam_read = wheel_move.logging_node:main",
        ],
    },
)

            